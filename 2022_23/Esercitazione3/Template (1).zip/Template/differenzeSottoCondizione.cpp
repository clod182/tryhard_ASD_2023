#include <vector>

using namespace std;

void differenzeSottoCondizione(vector<int>& arr){
}