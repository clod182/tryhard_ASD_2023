#include <vector>

using namespace std;

void differenze(vector<int>& arr){
}